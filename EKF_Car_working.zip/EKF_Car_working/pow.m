function p = pow(a,b)
%This function has been written so that the c syntax would be tested in
%matlab first before implementing in C

p = a^b;


end

