#ifndef DOG_H
#define DOG_H

class Dog {

public:
	int age;
	void bark();
};

#endif
