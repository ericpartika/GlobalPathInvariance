#include <iostream>
#include "Dog.h"

void Dog::bark() {
	std::cout << "Woof!" << std::endl;
}
